import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-memory-api',
  templateUrl: './memory-api.component.html',
  styleUrls: ['./memory-api.component.css']
})
export class MemoryAPIComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
