import { DndDirective } from './dnd.directive';

describe('DndDirective', () => {
  it('should create an instance', () => {
    const directive = new DndDirective();
    expect(directive).toBeTruthy();
  });
});
