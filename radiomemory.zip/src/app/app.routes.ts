import {Routes} from '@angular/router'

import {MemoryAPIComponent} from './memory-api/memory-api.component'

export const ROUTES: Routes = [
    {path: '', component: MemoryAPIComponent}
    ]